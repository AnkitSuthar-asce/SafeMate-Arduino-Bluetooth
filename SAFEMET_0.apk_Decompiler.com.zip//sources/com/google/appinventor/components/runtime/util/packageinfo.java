package com.google.appinventor.components.runtime.util;

/* renamed from: com.google.appinventor.components.runtime.util.package-info  reason: invalid class name */
interface packageinfo {
}
