package com.google.appinventor.components.runtime.util.theme;

public class ClassicThemeHelper implements ThemeHelper {
    public void requestActionBar() {
    }

    public boolean setActionBarVisible(boolean visible) {
        return false;
    }

    public boolean hasActionBar() {
        return false;
    }

    public void setTitle(String title) {
    }

    public void setActionBarAnimation(boolean enabled) {
    }

    public void setTitle(String title, boolean black) {
    }
}
